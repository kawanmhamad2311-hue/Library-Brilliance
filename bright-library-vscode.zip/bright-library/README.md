# 📚 کتێبخانەی بڕایت — Bright Library

سیستەمی بەڕێوەبردنی کتێبخانەی ئەلیکترۆنی بۆ ئینستیتوتی تەکنیکی بڕایت

---

## 🛠️ پێداویستیەکان (Requirements)

بەرپێش هەرشتێک، دڵنیا بە کە ئەمانەت دامەزراون:

| ئامراز | وەشان | بەستەر |
|-------|-------|--------|
| **Node.js** | v20+ | https://nodejs.org |
| **pnpm** | v9+ | `npm install -g pnpm` |
| **PostgreSQL** | v14+ | https://postgresql.org |

---

## 🗄️ دامەزراندنی داتابەیس

١. PostgreSQL دەست پێبکە
٢. داتابەیسێکی نوێ درووست بکە:

```sql
CREATE DATABASE bright_library;
```

٣. فایلی `.env` لە فۆڵدەری `api-server` نوێ بکەوە:

```
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/bright_library
JWT_SECRET=any-long-random-secret-string
PORT=8080
```

---

## 📦 دامەزراندن (Installation)

Terminal یان PowerShell بکەرەوە لە فۆڵدەری پڕۆژەکە و ئەمە بنووسە:

```bash
# 1. Package-ەکان دابمەزرێنە
pnpm install

# 2. داتابەیس Setup بکە (جەدوەلەکان درووست دەکاتەوە)
cd lib/db && pnpm run push && cd ../..
```

---

## ▶️ رەنکردن (Running)

Terminal-ی **یەکەم** — API Server:

```bash
cd api-server
pnpm dev
```

Terminal-ی **دووەم** — Frontend:

```bash
cd frontend
pnpm dev
```

سایتەکە لە ئەم بەستەرەوە کارادەکات: **http://localhost:3000**

---

## 🔑 چوونەژوورەوەی ئەدمین

| بەکارهێنەر | تێپەڕەوشە |
|-----------|-----------|
| `admin`   | `admin1234` |

---

## 📁 پێکهاتەی پڕۆژەکە (Structure)

```
bright-library/
├── frontend/           ← React + Vite (پەڕەکانی سایت)
│   └── src/
│       ├── pages/      ← Login, Library, BookDetail, Feedback, Admin
│       ├── components/ ← UI Components
│       └── contexts/   ← Auth Context
├── api-server/         ← Node.js + Express (API)
│   └── src/
│       ├── routes/     ← auth, books, feedback, admin, upload
│       └── lib/        ← auth helpers
└── lib/
    ├── db/             ← داتابەیس Schema (Drizzle ORM)
    ├── api-client-react/ ← React Hooks
    └── api-zod/        ← Validation Schemas
```

---

## 🌐 ئەندپۆینتەکانی API

| Method | Endpoint | وەسف |
|--------|----------|------|
| POST | /api/auth/login | چوونەژوورەوە |
| POST | /api/auth/register | تۆمارکردن |
| GET | /api/books | لیستی کتێبەکان |
| POST | /api/books | زیادکردنی کتێب (ئەدمین) |
| DELETE | /api/books/:id | سڕینەوەی کتێب (ئەدمین) |
| POST | /api/books/:id/download | دابەزاندن |
| GET | /api/feedback | بۆچوونەکان |
| POST | /api/feedback | زیادکردنی بۆچوون |
| GET | /api/admin/stats | ئاماری ئەدمین |
| POST | /api/upload/cover | بارکردنی وێنەی بەرگ |
