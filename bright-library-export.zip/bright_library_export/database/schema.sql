-- ============================================================
-- کتێبخانەی بڕایت - Bright Library Database Schema (MySQL)
-- BRIGHT Technical and Vocational Institute
-- ============================================================

SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- -------------------------------------------------------
-- 1. users table
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id`            INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `name`          VARCHAR(255)   NOT NULL,
  `username`      VARCHAR(100)   NOT NULL UNIQUE,
  `password_hash` TEXT           NOT NULL,
  `department`    VARCHAR(255)   NOT NULL,
  `badge_code`    VARCHAR(100)   NOT NULL,
  `role`          ENUM('student','admin') NOT NULL DEFAULT 'student',
  `created_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- 2. books table
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `books` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `title`          TEXT          NOT NULL,
  `author`         VARCHAR(255)  NOT NULL,
  `description`    TEXT          NOT NULL,
  `department`     VARCHAR(255)  NOT NULL,
  `pdf_url`        TEXT          NOT NULL,
  `cover_image`    TEXT          NULL,
  `download_count` INT           NOT NULL DEFAULT 0,
  `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- 3. feedback table
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `feedback` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NOT NULL,
  `book_id`    INT UNSIGNED NOT NULL,
  `content`    TEXT         NOT NULL,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_feedback_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_feedback_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- 4. downloads table
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `downloads` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`       INT UNSIGNED NOT NULL,
  `book_id`       INT UNSIGNED NOT NULL,
  `downloaded_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_downloads_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_downloads_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Default admin account (password: admin1234)
-- -------------------------------------------------------
INSERT INTO `users` (`name`, `username`, `password_hash`, `department`, `badge_code`, `role`)
VALUES (
  'Admin',
  'admin',
  '$2b$10$placeholder_replace_with_real_bcrypt_hash',
  'بەشی ئایتی',
  'ADMIN-001',
  'admin'
);
