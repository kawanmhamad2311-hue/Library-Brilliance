====================================================
کتێبخانەی بڕایت - Bright Library
BRIGHT Technical and Vocational Institute
====================================================

فۆڵدەرەکان / Folder Structure:
---------------------------------
frontend/         - ئاپی وێبی بناوبانگ (HTML + JS + CSS بناوی)
backend/          - کۆدی سێرڤەری API (Node.js / Express / TypeScript)
database/         - Schema-ی داتابەیس بە فۆرماتی MySQL

Tech Stack:
-----------
Frontend : React 18 + Vite + TailwindCSS + shadcn/ui
Backend  : Node.js + Express + TypeScript + Drizzle ORM
Database : PostgreSQL (Schema-ی MySQL زیادکراوە)
Auth     : JWT (bcrypt password hashing)

Departments / بەشەکان:
-----------------------
- بەشی پەرستاری
- بەشی تەکنیکی چاو
- بەشی ئایتی
- بەشی دەرمانسازی
- بەشی شیکاری نەخۆشیەکان
- بەشی میکانیکی ئۆتۆمبیل

API Endpoints:
--------------
POST   /api/auth/login
POST   /api/auth/register
GET    /api/books
GET    /api/books/:id
POST   /api/books             (admin only)
DELETE /api/books/:id         (admin only)
POST   /api/books/:id/download
GET    /api/feedback
POST   /api/feedback
GET    /api/admin/feedback    (admin only)
GET    /api/admin/downloads   (admin only)
POST   /api/upload/cover      (admin only)

Default Admin:
--------------
Username: admin
Password: admin1234
